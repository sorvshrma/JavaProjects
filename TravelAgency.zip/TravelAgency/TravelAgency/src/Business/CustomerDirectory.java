/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lionel
 */
public class CustomerDirectory {
    
    private List<Customer> customers = new ArrayList<Customer>();

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
    
    public boolean removeCustomer(Customer customer) {
        return customers.remove(customer);
    }

    public boolean addCustomer(Customer customer) {
        return customers.add(customer);
    }
    
}
