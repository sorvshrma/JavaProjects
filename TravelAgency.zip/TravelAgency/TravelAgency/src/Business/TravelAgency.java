/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import javax.swing.JPanel;

/**
 *
 * @author Ankit
 */
public class TravelAgency {

    private AirlinerDirectory airlinerDirectory;

    public TravelAgency(JPanel rightJPanel, TravelAgency travelAgency) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public AirlinerDirectory getAirlinerDirectory() {
        return airlinerDirectory;
    }

    public TravelAgency() {
        this.airlinerDirectory = new AirlinerDirectory();
    }

    public void setAirlinerDirectory(AirlinerDirectory airlinerDirectory) {
        this.airlinerDirectory = airlinerDirectory;
    }

    @Override
    public String toString() {
        return "TravelAgency{" + "airlinerDirectory=" + airlinerDirectory + '}';
    }
    
    

}
