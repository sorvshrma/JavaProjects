/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Lionel
 */
public class Airliner {

    private String airlinerName;
    private int fleetSize;
    private FlightDirectory flightDirectory;

    public FlightDirectory getFlightDirectory() {
        return flightDirectory;
    }

    public void setFlightDirectory(FlightDirectory flightDirectory) {
        this.flightDirectory = flightDirectory;
    }

    public Airliner() {
        this.flightDirectory = new FlightDirectory();
       
    }

    public String getAirlinerName() {
        return airlinerName;
    }

    public void setAirlinerName(String airlinerName) {
        this.airlinerName = airlinerName;
    }

    public int getFleetSize() {
        return fleetSize;
    }

    @Override
    public String toString() {
        return this.airlinerName;
    }

    public void setFleetSize(int fleetSize) {
        this.fleetSize = fleetSize;
    }
}
