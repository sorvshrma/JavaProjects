/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ankit
 */
public class Seat{
    
private boolean isAvailable;
private String seatNumber;

    public Seat(boolean isAvailable, String seatNumber) {
        this.isAvailable = isAvailable;
        this.seatNumber = seatNumber;
    }

    @Override
    public String toString() {
        return this.seatNumber;
    }
   
}
