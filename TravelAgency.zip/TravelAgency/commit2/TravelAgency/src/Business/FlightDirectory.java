/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lionel
 */
public class FlightDirectory {

    private List<Flight> flights = new ArrayList<Flight>();

    public List<Flight> getFlights() {
        return flights;
    }

    public void setFlights(List<Flight> flights) {
        this.flights = flights;
    }

    public boolean removeFlight(Flight flight) {
        return flights.remove(flight);
    }

    public boolean addFlights(Flight flight) {
        return flights.add(flight);
    }

}
