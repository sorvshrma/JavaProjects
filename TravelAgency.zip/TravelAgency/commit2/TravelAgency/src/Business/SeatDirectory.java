/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ankit
 */
public class SeatDirectory {
     private List<Seat> seats;

    public SeatDirectory() {
        this.seats = new ArrayList<>();
    }
   
   
   public void assignSeats(){
       for(int i=1; i<=25; i++)
       {
           seats.add(new Seat(true, "A"+i));
           seats.add(new Seat(true, "B"+i));
           seats.add(new Seat(true, "C"+i));
           seats.add(new Seat(true, "D"+i));
           seats.add(new Seat(true, "E"+i));
           seats.add(new Seat(true, "F"+i));
           
       }
       
   }
    
}
