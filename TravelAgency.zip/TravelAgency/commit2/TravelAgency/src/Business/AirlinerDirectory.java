/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lionel
 */
public class AirlinerDirectory {

    private List<Airliner> airliners;

    public AirlinerDirectory() {
        this.airliners = new ArrayList<>();
    }

    public List<Airliner> getAirliners() {
        return airliners;
    }

    public void setAirliners(List<Airliner> airliners) {
        this.airliners = airliners;
    }

    public boolean addAirliner(Airliner airliner) {
        return airliners.add(airliner);
    }

    public boolean removeAirliner(Airliner airliner) {
        return airliners.remove(airliner);
    }

}
